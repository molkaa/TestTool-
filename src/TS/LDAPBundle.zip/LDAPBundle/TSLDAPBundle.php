<?php

namespace TS\LDAPBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TSLDAPBundle extends Bundle
{
}
