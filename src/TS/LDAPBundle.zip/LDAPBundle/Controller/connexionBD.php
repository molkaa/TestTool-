<?php
include('adodb.inc.php');

$targetDatabase = 'symfony';
$targetServer = 'localhost';
$usename = 'root';
$password = '';
$conn = ADONewConnection('mysql'); 
$conn->PConnect($targetServer,$usename,$password,$targetDatabase);

?>